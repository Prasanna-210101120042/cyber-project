<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location:index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["imageUpload"])) {
    // File handling and processing logic
    $uploadDir = 'uploads/';
    $uploadedFile = $uploadDir . basename($_FILES['imageUpload']['name']);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($uploadedFile, PATHINFO_EXTENSION));

    // Check if file is an APK
    if ($fileType != "apk") {
        echo "Sorry, only APK files are allowed.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($uploadedFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES['imageUpload']['size'] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats
    if ($fileType != "apk") {
        echo "Sorry, only APK files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // If everything is ok, try to upload file
        if (move_uploaded_file($_FILES['imageUpload']['tmp_name'], $uploadedFile)) {
            echo "The file " . basename($_FILES['imageUpload']['name']) . " has been uploaded.";

            // Execute shell command to scan APK for vulnerabilities
            $scanResult = shell_exec("scanner_command " . $uploadedFile);

            // Output scan result
            echo "<br>Scan Result: " . $scanResult;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image</title>
    <link rel="stylesheet" type="text/css" href="upload.css">
</head>

<body>
    <div class="container">
        <h1>Upload Your File</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"
            enctype="multipart/form-data">
            <label for="imageUpload" class="custom-file-upload">
                <span><i class="fas fa-cloud-upload-alt"></i> Choose File</span>
            </label>
            <input type="file" id="imageUpload" name="imageUpload" accept=".apk">
            <input type="submit" value="Upload" class="upload-button">
        </form>
    </div>
</body>

</html>