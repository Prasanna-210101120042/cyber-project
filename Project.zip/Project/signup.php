<?php
    $login = false;
    include('connection.php');
    if (isset($_POST['signup'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $username = $_POST['username'];

        //how to insert data into database in php
        $query = " INSERT INTO users VALUES('', '$username', '$email', '$password', '$name')";
        mysqli_query($conn,$query);
        echo
        "<script> alert('Data Inserted Successfully.') </script>";

    }
    ?>





<!DOCTYPE html>
<html lang="en">

<head>
    <title>Signup</title>
    <link rel="stylesheet" href="signup.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>

<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">ScanDroid</h2>
            </div>

            <div class="menu">
                <ul>
                    <!--<li><a href="#"><ion-icon name="home"></ion-icon></i>HOME</a></li>-->
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">
                                <ion-icon name="home"></ion-icon></i><b>HOME</b>
                                <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="#"> cyber security project web page design
                                    sampleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee </a>
                                <a href="#">Link 2</a>
                                <a href="#">Link 3</a>
                            </div>
                        </div>
                    </li>

                    <li>
                        <!-- <a href="#"><ion-icon name="person-circle"></ion-icon></i>ABOUT</a>-->
                        <div class="dropdown">
                            <button class="dropbtn">
                                <ion-icon name="person-circle"></ion-icon></i><b>ABOUT</b>
                                <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="#">An automated tool for review cyber security</a>
                                <a href="#">Link 2</a>
                                <a href="#">Link 3</a>
                            </div>
                        </div>

                    </li>

                    <li>
                        <!--<a href="#"><ion-icon name="shield-checkmark"></ion-icon>SERVICE</a>-->
                        <div class="dropdown">
                            <button class="dropbtn">
                                <ion-icon name="shield-checkmark"></ion-icon></i><b>SERVICE</b>
                                <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="#">Overview Job readiness syllabus job readiness gallery,</a>
                                <a href="#">Study Material</a>
                                <a href="#">Link 3</a>
                            </div>
                        </div>
                    </li>

                    <li>
                        <!--<a href="#"><ion-icon name="call"></ion-icon>CONTACT</a>-->
                        <div class="dropdown">
                            <button class="dropbtn">
                                <ion-icon name="call"></ion-icon></i><b>CONTACT</b>
                                <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="#">Schools & Programmes in CUTM Odisha</a>
                                <a href="#">Career and development cell</a>
                                <a href="#">Link 3</a>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>



        </div>
        <div class="content">
            <h1>An Automated <br><span>Tool For</span> <br>Review</h1>



            <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" class="form">
                <h2>Register Here</h2>
                <form method="post">
                    <input type="username" name="username" placeholder="First Name">
                    <input type="text" name="name" placeholder="Last name">
                    <input type="email" name="email" placeholder="Enter Email ">
                    <input type="paassword" name="password" placeholder="Enter Password">

                    <!-- <input type="password" name="password" placeholder="Create Password "
                    <input type="password" name="cpassword" placeholder="Confirm Password "> -->

                    <button type="submit" name="signup" class="btnn"><a href="#">Submit</a></button>

                    <p class="link">Don't have an account<br>
                        <a href="index.php">Login </a> here</a>
                    </p>
                </form>

        </div>


    </div>
    </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>

</html>