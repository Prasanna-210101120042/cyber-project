<?php error_reporting(E_ALL);

/*
functions for:
1.) Running the .apk file
2.) Searching for the word httpClient and DefaultHttpClient
and showing the result
*/

function run_app(){
echo shell_exec("adb version");
}

function jad($path)
{
shell_exec("cd apks ;cd ".$path." ; unzip app.jar -d classfoldr;jad -o -r -sjava -dsrc classfoldr/\\/\*.class ; ") or die("error in asdlfja");
}

function loop_dir($path,$str,$flag){
$dir=scandir($path);
 for($i=2;$i<sizeof($dir);$i++)
  {
    $ele=$dir[$i];
     if(is_dir($path."/".$ele)){ $flag=loop_dir($path."/".$ele,$str,$flag); }
     else{  $flag=search_strin($path."/".$ele,$str,$flag);  }
   }
 return $flag;
}

//search the string in the file
function search_strin($file,$string,$flag)
{ $res="";
 $lines=file($file);
 foreach($lines as $linenum=>$line)
 {
  if(strpos($line,$string)!==false)
   { $flag=1;
	$res= $linenum." : ".$file." <br> ";
   }
 }
return $flag;
}

jad($path);

$cur=getcwd();$arra=array(
array("Sensitive Data in Shared Preferences","putString","MODE_PRIVATE","MODE_WORLD_READABLE","MODE_WORLD_WRITABLE"),
array("Weak Transportation","HttpURLConnection","URLConnection","TrustAllSSL-SocketFactory","AllTrustSSLSocketFactory","NonValidatingSSLSocketFactory"),
array("Possible SQL Content","db","Sqlite","Database","cursor","Table"),
array("LocationInfo","getLastKnownLocation","requestLocationUpdates()","getLatitude","getLongitude"),
array("possible script Injection","addJavascriptInterface()","setJavaScriptEnabled(true)")
);

?>

<style>
.rel {
    position: relative;
    float: left;
    left: 0px;
}

.bordred {
    border: 2px ridge #ffa8a8;
    border-radius: 3px;
    padding: 10px;
}

.bordgr {
    border-radius: 3px;
    border: 2px ridge #a8ffa8;
    padding: 10px;
}

.wid100 {
    width: 95%;
}

.block {
    width: 700px;
    padding: 10px;
    border-radius: 4px;
    border: 2px ridge #10c878;
}

.tite {
    font-family: Helvetica, arial, "sans-serif";
    font-weight: bold;
    text-align: center;
    padding: 5px;
}
</style>
<?php

foreach($arra as $string)
{   $flag=0;
	echo "<div class='rel block'><div class='rel tite wid100'>".$string[0]."</div>";
	for($i=1;$i<sizeof($string);$i++)
	{ $str=$string[$i];
	  $flag=loop_dir($cur."/apks/".$path."/src",$str,$flag);
            if($flag==1){ echo "<div class='rel bordred wid100'>String found ".$str."</div><br>";  }
	    else{ echo "<div class='rel bordgr wid100'>Didn't Found the String ".$str."</div><br>";  }
         }
	echo "</div>";
}

?>
</div>

<?php

//loading the file //
$my=simplexml_load_file("apks/".$path."/".$fil."/AndroidManifest.xml") or die("Error in ".$path);


/*
wrting the function which gets the tag 
and checks the attributes of the tag
and sends it children tag for its attributes
*/
$res = "";

function child($x, $res) {
    $se = ""; // Initialize $se within the function

    foreach ($x->children() as $child) {
        if ($child->getName() == "application") {
            foreach ($child->attributes("android", true) as $att => $a) {
                if ((strcmp($att, "allowBackup") == 0 || strcmp($att, "debuggable") == 0) && $a == "true") {
                    $se .= $child->getName() . ":" . $att . "=" . $a . "</br>"; 
                }
            }
        } else {
            // Call 'fun' function and concatenate result to $se
            $se .= fun($child->getName(), $child, $res); 
        }
        
        // Sending its child (recursive call)
        $se .= child($child, $res);
    }

    return $se;
}

/*
this is the function 
which gets the tag and tagname
to check the attributes
*/
function fun($x,$y,$res){
	if($x=="activity" || $x=="service" || $x=="provider" || $x=="receiver")
	{
	 foreach($y->attributes("android",true) as $att=>$a)
	{
	if($att=="exported" && $a=="true") { $res.="<br>".$y->getName()." android:".$att."=".$a."<br>";}
	}
  }
else if($x=="uses-permission")
{
   echo $x;
  foreach($y->attributes("android",true) as $att=>$b  )
  {
	$res.=" android:".$att."=".$b;
  } $res.="<br>";
}
return $res;
}

//calling the function with main tag in the file //
$res=child($my,$res);
echo "<div class='rel block'><div class='rel wid100 bordred'>".$res."</div></div>";
?>